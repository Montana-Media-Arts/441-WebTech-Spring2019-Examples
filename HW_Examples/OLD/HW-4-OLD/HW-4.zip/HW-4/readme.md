# HW-4 test readme

This is the empty shell for the the HW-4 assignment. Please copy it and place it in your git repo directory.

To upload, place a link to your directory on the HW-4 wiki.

Please, also create a zip'd file containing the finished HW-4 directory, place this _INSIDE_ the HW-4 directory.
