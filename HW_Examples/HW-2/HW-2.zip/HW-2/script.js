// Example of Using the document.write
// function to place text in an HTML document

document.write("<h1>HW-2 With JS</h1><p>'Hello World!' from JavaScript land!!!");
