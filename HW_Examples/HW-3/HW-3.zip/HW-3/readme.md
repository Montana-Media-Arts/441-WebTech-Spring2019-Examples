# HW-3 Readme for YOUR_NAME

Please place your response to this week here. 
