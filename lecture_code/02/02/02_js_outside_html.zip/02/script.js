// Example of an external JavaScipt File

console.log("Hello World!");
// If you open the web console,
// you will see "Hello World!" printed, just like before.
