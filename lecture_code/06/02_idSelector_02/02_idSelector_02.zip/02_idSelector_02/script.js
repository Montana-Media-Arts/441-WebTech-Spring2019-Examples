let node = document.querySelector('#d1');
node.innerText = "hey there";
