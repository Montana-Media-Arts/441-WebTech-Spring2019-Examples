function popup() {
    alert('You pressed the button!');
}
