// This is a JavaScript file.
// We can run this file with NODE.js
// or it can be run by a browser's JS "engine"

console.log("Hello World! (again), from a seperate JS file!");
