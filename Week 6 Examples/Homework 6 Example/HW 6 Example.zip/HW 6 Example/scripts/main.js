var firstNumber = -1;
var imageNames = ["image1", "image2", "image3", "image4"];
var blankImages = ["images/gofish.jpg", "images/gofish.jpg", "images/gofish.jpg", "images/gofish.jpg"];

// json
var player = {"firstname":"", "lastname":"fsjk"};

function printBlanks()
{
    
    
    for(var i = 0; i < blankImages.length; i++)
    {
        document.getElementById(imageNames[i]).src=blankImages[i];
    }
}



function flipImage(number)
{
    var actualImages = ["images/dog.jpg", "images/tiger.jpeg", "images/dog.jpg", "images/tiger.jpeg"];
    
    document.getElementById(imageNames[number]).src = actualImages[number];
    firstNumber = number;
    setTimeout(imagesDisappear, 1000);
}

function imagesDisappear()
{
    document.getElementById(imageNames[firstNumber]).src=blankImages[firstNumber];
   
}

function addToPlayer()
{
    player.firstname = document.getElementById("txtFirstName").value;
    localStorage.setItem("playerInfo", JSON.stringify(player));
    window.location = "HWExample.html";
}

function playerInfo()
{
    var playerInformation = localStorage.getItem("playerInfo");
    player = JSON.parse(playerInformation);
   
}